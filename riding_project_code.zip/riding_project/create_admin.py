from app import Users,db
admin = Users.query.filter_by(is_admin=True).first()

if admin:
    print("Admin Already Exists")
else:
    new_admin = Users(email="theadmin@gmail.com",password="Admin",is_admin=True)
    db.session.add(new_admin)
    db.session.commit()
    print("Admin Created Successfully")