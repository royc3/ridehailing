from flask import Flask,Blueprint,jsonify,request,render_template,url_for,redirect,flash,session
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from datetime import datetime
from flask_login import LoginManager
import stripe
from flask_login import login_user, current_user, logout_user, login_required

app = Flask(__name__)
app.config['SECRET_KEY'] = '5791628bb0b13ce0c676dfde280ba245'
app.config['SQLALCHEMY_DATABASE_URI'] = "mysql://root:@localhost/ride"

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
Migrate(app,db)

login_manager = LoginManager(app)


from flask_login import UserMixin

login_manager.login_view = 'Login'

stripe.api_key = 'sk_test_51Li9vSLrpfnp4zWJmdpNm8vuzpLLpwbbVGzfytQbeVWeYDE9wXSH48h1Rsufx08gqTyqefTlYhSop6AZJh3vprXJ00xTEddr3r'


@login_manager.user_loader
def load_user(id):
        
    return Users.query.get(int(id))


class Users(db.Model,UserMixin):
    id = db.Column(db.Integer(), primary_key=True)
    email = db.Column(db.String(100),nullable=False)
    
    password= db.Column(db.String(200),nullable=False)
    

    is_admin = db.Column(db.Boolean(),nullable=True,default=False)

class Location(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)


# Define the Booking model
class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    
    location_name = db.Column(db.String(100), nullable=False)
    created_date = db.Column(db.DateTime, default=datetime.utcnow)



# Routes

@app.route('/login',methods=['POST','GET'])
def Login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        print(email)

        admin = Users.query.filter_by(email=email).first()
        if admin and admin.password == password and admin.is_admin == True:
            
            login_user(admin,True)
            flash("Logged in as admin successfully",'info')
            return redirect(url_for('admin'))

        flash('Invalid username or password.', 'error')
    return render_template('login.html')


# Admin Route - Add Location
@app.route('/admin', methods=['GET', 'POST'])
@login_required
def admin():
    if request.method == 'POST':
        name = request.form['location_name']
        price = float(request.form['location_price'])
        new_location = Location(name=name, price=price)
        db.session.add(new_location)
        db.session.commit()
        return redirect(url_for('admin'))

    locations = Location.query.all()
    return render_template('admin.html', locations=locations)



# Admin Booking Page Route
@app.route('/admin/bookings')
@login_required
def admin_bookings():
    # Retrieve all bookings from the database
    bookings = Booking.query.all()
    return render_template('admin_bookings.html', bookings=bookings)


@app.route('/')
def index():
    # Get all locations from the database
    locations = Location.query.all()
    return render_template('index.html', locations=locations)

@app.route('/location/<int:location_id>/checkout',methods=['GET','POST'])
def checkout(location_id):
    location = Location.query.get(location_id)
    session['location_id'] = location_id

    if request.method == "POST":
        amount = int(location.price)
        customer = stripe.Customer.create(
            email=request.form['stripeEmail'],
            source=request.form['stripeToken']
            )
        

        stripe.Charge.create(
            customer=customer.id,
            amount=amount*100,
            currency='usd',
            description=location.name +' Ride Charge'
        )

        return redirect(url_for('payment_success'))
    return render_template('checkout.html', location=location)

@app.route('/payment_success')
def payment_success():
    if 'location_id' in session:
        location_id = session['location_id']
        location = Location.query.get(location_id)
        if location:
            
            booking = Booking(location_name=location.name)
            db.session.add(booking)
            db.session.commit()
            session.pop('location_id')
        else:
            flash('Invalid location selected.', 'error')
           
    else:
        flash('Booking data not found.', 'error')

    # Handle successful payment here (e.g., display a success message)
    return render_template('payment_success.html')

@app.route('/logout')
def Logout():
    logout_user()
    flash('Logged out successfully','success')
    return redirect(url_for('index'))


app.app_context().push()
if __name__ == '__main__':
    app.run(debug=True)